const moment = require("moment");
const { ObjectId } = require("mongodb");

function fillMissingDataByYears(data) {
  try {
    let arr = data;
    let i = 0;

    if (data.length === 0) return;

    let year = moment(arr[0].period).year();
    let latestYear = new Date().getFullYear() + 1;

    if (arr.length > 1) {
      for (i; i < arr.length - 1; i++) {
        if (
          moment(arr[i + 1].period).year() - moment(arr[i].period).year() >
          1
        ) {
          const currentYear = moment(arr[i].period).year();

          let _id = new ObjectId();
          let entityID = new ObjectId(arr[arr.length - 1]["entityID"]);
          let _insertedBy = undefined;
          let _updatedBy = undefined;

          const obj = {
            ...arr[i],
            _id,
            entityID,
            period: new Date(`${currentYear + 1}-01-15`),

            insertedBy: _insertedBy ? new ObjectId(_insertedBy) : null,
            updatedBy: _updatedBy ? new ObjectId(_updatedBy) : null,
            actual: false,
            carriedOver: true,
            // type1: true,
          };

          arr.splice(i + 1, 0, obj);
        }

        if (latestYear - moment(arr[arr.length - 1].period).year() > 1) {
          const year = moment(arr[arr.length - 1].period).year();

          let _id = new ObjectId();
          let entityID = new ObjectId(arr[arr.length - 1]["entityID"]);
          // let _insertedBy = arr[arr.length - 1]["insertedBy"]
          //   ? new ObjectId(arr[arr.length - 1]["insertedBy"])
          //   : undefined;
          let _insertedBy = undefined;
          // let _updatedBy = arr[arr.length - 1]["updatedBy"]
          //   ? new ObjectId(arr[arr.length - 1]["updatedBy"])
          //   : undefined;
          let _updatedBy = undefined;

          const obj = {
            ...arr[arr.length - 1],
            _id,
            entityID,
            period: new Date(`${year + 1}-01-15`),

            insertedBy: _insertedBy,
            updatedBy: _updatedBy,
            actual: false,
            carriedOver: true,
            // type2: true,
          };

          arr.push(obj);
        }
      }
    } else {
      for (i; i <= arr.length - 1; i++) {
        if (latestYear - moment(arr[arr.length - 1].period).year() > 1) {
          const year = Number(moment(arr[arr.length - 1].period).year());

          let _id = new ObjectId();
          let entityID = new ObjectId(arr[arr.length - 1]["entityID"]);
          let _insertedBy = undefined;
          let _updatedBy = undefined;

          const obj = {
            ...arr[arr.length - 1],
            _id,
            entityID,
            period: new Date(`${year + 1}-01-15`),

            insertedBy: _insertedBy,
            updatedBy: _updatedBy,
            actual: false,
            carriedOver: true,
            // type3: true,
          };

          arr.push(obj);
        }
      }
    }

    return arr;
  } catch (error) {
    console.log("fillMissingDateByYears", error);
  }
}

module.exports = { fillMissingDataByYears };
