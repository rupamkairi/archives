const { MongoClient, ObjectId } = require("mongodb");

const MONGO_URL =
  "mongodb+srv://pawan_rw:pawan2023swfi@swfi-dev-cluster.wgvigu5.mongodb.net/swfi";
// const MONGO_URL = "";
// const MONGO_URL = "";

// const AUM = "entitiesAUM";
const AUM = "entitiesAUM_Production";
const ENT = "entities_QA";
const upAUM = AUM;
const errAUM = "entitiesAUM_Error";

class MongoDB {
  constructor() {
    this.mongo = {};
  }

  async setup() {
    this.mongo = new MongoClient(MONGO_URL, {
      useUnifiedTopology: true,
      useNewUrlParser: true,

      // maxPoolSize: 2000,
      // waitQueueTimeoutMS: 300000,
      // connectTimeoutMS: 300000,
      // socketTimeoutMS: 300000,
      // maxIdleTimeMS: 150000,
    });

    await this.mongo.connect();
    return this.mongo;
  }

  async generateFullData() {
    try {
      // const mongo = await mongoConnectAsync();
      const db = this.mongo.db("swfi");
      const aum = db.collection(AUM);
      console.log("Running Pipeline");
      const docs = await aum.aggregate(entitiesAUMPipeline(ENT)).toArray();
      // await mongo.close();
      return docs[0]?.uniqes;
    } catch (error) {
      console.log("Error While running aggregation", error);
    }
  }

  async findAUMData(entityID) {
    try {
      // const mongo = await mongoConnectAsync();
      const db = this.mongo.db("swfi");
      const aum = db.collection(AUM);
      const docs = aum
        .find({ entityID: new ObjectId(entityID) }, { sort: { period: 1 } })
        .toArray();
      // await mongo.close();
      return docs;
    } catch (error) {
      console.log("Error While Finding AUM Data for entity", entityID, error);
    }
  }

  async insertManyToAUMData(data, extra = null) {
    try {
      // const mongo = await mongoConnectAsync();
      const db = this.mongo.db("swfi");
      const aum = db.collection(upAUM);
      const writeData = data.filter((el) => el.carriedOver == true);
      const result = await aum.insertMany(writeData, {
        ordered: true,
      });
      console.log(
        result.insertedCount,
        "additional doc inserted for entity",
        data[0].entityID
      );
      // await mongo.close();
      return result;
    } catch (error) {
      console.warn("insertManyToAUMData", data[0].entityID, error.message);
      const errorData = {
        entityID: new ObjectId(data[0].entityID),
        error: error.message,
      };
      await this.insertErrored(errorData);
    }
  }

  async insertErrored(data) {
    try {
      // const mongo = await mongoConnectAsync();
      const db = this.mongo.db("swfi");
      // console.log("Inserting Errored Data");
      const err = db.collection(errAUM);
      const result = await err.insertOne(data, {
        ordered: true,
      });
      // console.log(result, "doc inserted");
      // await mongo.close();
      return result;
    } catch (error) {
      console.log("While Handling Error, another error occured", error);
      console.log("\nWierd Error ** ##\n");
    }
  }
}

async function mongoConnectAsync() {
  let mongo = new MongoClient(MONGO_URL, {
    useUnifiedTopology: true,
    useNewUrlParser: true,

    // maxPoolSize: 2000,
    // waitQueueTimeoutMS: 300000,
    // connectTimeoutMS: 300000,
    // socketTimeoutMS: 300000,
    // maxIdleTimeMS: 150000,
  });

  await mongo.connect();

  return mongo;
}

var entitiesAUMPipeline = (entitiesCollection) => [
  // {
  //   $match: {
  //     $or: [{ carriedOver: { $exists: false } }],
  //   },
  // },
  {
    $project: {
      entityID: 1,
      carriedOver: 1,
      currency: 1,
    },
  },
  {
    $lookup: {
      from: entitiesCollection,
      localField: "entityID",
      foreignField: "_id",
      as: "entity",
    },
  },
  {
    $unwind: {
      path: "$entity",
      preserveNullAndEmptyArrays: false,
    },
  },
  {
    $project: {
      entityID: 1,
      "entity.name": 1,
      "entity.defunct": 1,
      carriedOver: 1,
      currency: 1,
    },
  },
  {
    $match: {
      $or: [
        { "entity.defunct": false },
        { "entity.defunct": "" },
        { "entity.defunct": { $ne: true } },
        { "entity.defunct": { $ne: "true" } },
      ],
    },
  },
  {
    $group: {
      _id: "$entityID",
      count: { $sum: 1 },
      carriedOvers: { $addToSet: "$carriedOver" },
    },
  },
  {
    $group: {
      _id: "null",
      uniqes: {
        $addToSet: {
          $cond: {
            if: { $in: [true, "$carriedOvers"] },
            then: "$REMOVE",
            else: "$_id",
          },
        },
      },
    },
  },
];

module.exports = entitiesAUMPipeline;

module.exports = {
  // mongoConnectAsync,
  // generateFullData,
  // findAUMData,
  // insertManyToAUMData,
  MongoDB,
};
