const { MongoClient, ObjectId } = require("mongodb");

const MONGO_URL =
  "mongodb+srv://pawan_rw:pawan2023swfi@swfi-dev-cluster.wgvigu5.mongodb.net/swfi";

async function mongoConnectAsync() {
  let mongo = new MongoClient(MONGO_URL, {
    useUnifiedTopology: true,
    useNewUrlParser: true,

    waitQueueTimeoutMS: 10000,
    socketTimeoutMS: 30000,
    maxIdleTimeMS: 10000,
  });

  // console.log("before connect", mongo);
  await mongo.connect();
  // console.log("after connect", mongo);

  const db = mongo.db("swfi");

  return db;
}

// const AUM = "entitiesAUM";
// const ENT = "entities";
// const AUM = "entitiesAUM_temp";
const AUM = "entitiesAUM_QA";
const ENT = "entities_QA";

async function generateFullData() {
  try {
    const db = await mongoConnectAsync();
    const aum = db.collection(AUM);
    console.log("Running Pipeline");
    const docs = await aum.aggregate(entitiesAUMPipeline(ENT)).toArray();
    return docs[0]?.uniqes;
  } catch (error) {
    console.log("generateFullData", error);
  }
}

async function findAUMData(entityID) {
  try {
    const db = await mongoConnectAsync();
    // console.log("Fetching Data");
    const aum = db.collection(AUM);
    const docs = aum
      .find({ entityID: new ObjectId(entityID) }, { sort: { period: 1 } })
      .toArray();
    return docs;
  } catch (error) {
    console.log("findAUMData", error);
  }
}

const upAUM = AUM;

async function insertManyToAUMData(data, extra = null) {
  try {
    const db = await mongoConnectAsync();
    // console.log("Inserting Data");
    const aum = db.collection(upAUM);
    const writeData = data.filter((el) => el.carriedOver == true);
    const result = await aum.insertMany(writeData, {
      ordered: true,
    });
    console.log(result.insertedCount, "doc inserted");
    return result;
  } catch (error) {
    console.log("insertManyToAUMData", data[0].entityID, error.message);
    const errorData = {
      entityID: new ObjectId(data[0].entityID),
      error: error.message,
    };
    await insertErrored(errorData);
  }
}

const errAUM = "entitiesAUMErrors";

async function insertErrored(data) {
  try {
    const db = await mongoConnectAsync();
    console.log("Inserting Errored Data");
    const err = db.collection(errAUM);
    const result = await err.insertOne(data, {
      ordered: true,
    });
    console.log(result, "doc inserted");
    return result;
  } catch (error) {
    console.log("insertErrored", error);
    console.log("\nWierd Error ** ##\n");
  }
}

var entitiesAUMPipeline = (entitiesCollection) => [
  // {
  //   $match: {
  //     $or: [{ carriedOver: { $exists: false } }],
  //   },
  // },
  {
    $project: {
      entityID: 1,
      carriedOver: 1,
      currency: 1,
    },
  },
  {
    $lookup: {
      from: entitiesCollection,
      localField: "entityID",
      foreignField: "_id",
      as: "entity",
    },
  },
  {
    $unwind: {
      path: "$entity",
      preserveNullAndEmptyArrays: false,
    },
  },
  {
    $project: {
      entityID: 1,
      "entity.name": 1,
      "entity.defunct": 1,
      carriedOver: 1,
      currency: 1,
    },
  },
  {
    $match: {
      $or: [
        { "entity.defunct": false },
        { "entity.defunct": "" },
        { "entity.defunct": { $ne: true } },
        { "entity.defunct": { $ne: "true" } },
      ],
    },
  },
  {
    $group: {
      _id: "$entityID",
      count: { $sum: 1 },
      carriedOvers: { $addToSet: "$carriedOver" },
    },
  },
  {
    $group: {
      _id: "null",
      uniqes: {
        $addToSet: {
          $cond: {
            if: { $in: [true, "$carriedOvers"] },
            then: "$REMOVE",
            else: "$_id",
          },
        },
      },
    },
  },
];

module.exports = entitiesAUMPipeline;

module.exports = {
  mongoConnectAsync,
  generateFullData,
  findAUMData,
  insertManyToAUMData,
};
