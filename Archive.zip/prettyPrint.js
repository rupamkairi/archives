function prettyPrintTable(data) {
  try {
    const tableData = data.map((el) => ({
      _id: el?._id + " <" + typeof el?._id + ">",
      entityID: el?.entityID + " <" + typeof el?.entityID + ">",
      actual: el.actual,
      period: el.period,
      assets: el.assets,
      equity: el.equity,
      // liabilities: el.liabilities,
      // insertedBy: el?.insertedBy + " <" + typeof el?.insertedBy + ">",
      // updatedBy: el?.updatedBy + " <" + typeof el?.updatedBy + ">",
      carriedOver: el?.carriedOver,
      // type1: el?.type1,
      // type2: el?.type2,
    }));
    console.table(tableData);
  } catch (error) {}
}

module.exports = { prettyPrintTable };
