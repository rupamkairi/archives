const { Queue, Worker } = require("bullmq");
const IORedis = require("ioredis");
const {
  findAUMData,
  insertManyToAUMData,
  generateFullData,
} = require("./mongodb.utils");
const { fillMissingDataByYears } = require("./fillMissingDataByYears");
const { prettyPrintTable } = require("./prettyPrint");

const Q_NAME = "entitiesAUM";

const redis = new IORedis({
  host: "127.0.0.1",
  port: 6379,
});

var fullData = [];
var pass = 0;
var step = 10;

// const redis = new IORedis({
//   host: "witty-katydid-43660.upstash.io",
//   port: 43660,
//   username: "default",
//   password: "cce60b66482c4aee94ea8a5d38c4e122",
// });

// const redis = new IORedis({
//   host: "redis-14372.c57.us-east-1-4.ec2.cloud.redislabs.com",
//   port: 14372,
//   username: "default",
//   password: "L4SKEk01OFKdnvxfrIoEm27VML9UbYiY",
// });

const queue = new Queue(Q_NAME, {
  connection: redis,
});

const worker = new Worker(
  Q_NAME,
  async (job) => {
    try {
      const entityID = job.data;
      console.log("worker has", entityID);
      const data = await findAUMData(entityID);
      const updated = fillMissingDataByYears(data);
      // prettyPrintTable(updated);
      const results = await insertManyToAUMData(updated);
      // console.log(results);
    } catch (error) {
      console.log("Errored", error);
      const jobCounts = await queue.getJobCounts("active", "waiting", "failed");
      console.log("Jobs failed", jobCounts);
      console.log("closing all connections...");
      await queue.drain();
      redis.disconnect();
      await worker.close();
    }
  },
  {
    connection: redis,
    concurrency: 5,
  }
);

// async function addToJob(payload) {
//   try {
//     const entityID = payload;
//     console.log("worker has", entityID);
//     const data = await findAUMData(entityID);
//     const updated = fillMissingDateByYears(data);
//     // prettyPrintTable(updated);
//     const results = await insertManyToAUMData(updated);
//     // console.log(results);
//   } catch (error) {
//     console.log("Errored", error);
//     // const jobCounts = await queue.getJobCounts("active", "waiting", "failed");
//     // console.log("Jobs failed", jobCounts);
//     console.log("closing all connections...");
//     // await queue.drain();
//     // redis.disconnect();
//     // await worker.close();
//   }
// }

async function addToJob(data) {
  await queue.add(Q_NAME, data, { removeOnComplete: true, removeOnFail: true });
}

async function pushToQueue(data) {
  for (let i = 0; i < data.length; i++) {
    await addToJob(data[i]);
  }
}

worker.on("active", (job) => {
  // console.log(job.id, "active");
});

worker.on("completed", async (job) => {
  const { active } = await queue.getJobCounts("active", "waiting", "failed");
  // console.log(job.id, "complete", { active });
  if (active == 0) {
    console.log("All jobs done successfully...");

    pass += 1;
    const data = fullData.slice(pass * step, (pass + 1) * step);
    console.log({ data, pass, step });
    // if (data.length === 0) return;
    await pushToQueue(data);

    // redis.disconnect();
    // await worker.close();
  }
});

worker.on("failed", (job, err) => {
  // console.log(job.id, "errored", err);
});

(async function main() {
  try {
    fullData = await generateFullData();
    console.log(fullData.length, "found on pipeline");

    const data = fullData.slice(pass * step, (pass + 1) * step);
    console.log({ data, pass, step });
    await pushToQueue(data);

    //
    // for (let i = 0; i < fullData.length; i++) {
    //   // const counter = i + 1;
    //   // const pattern = `${counter} * * * * *`;
    //   // cron.schedule(pattern, async () => {
    //   await addToJob(fullData[i]);
    //   // });
    // }
  } catch (error) {
    console.log("error in main", error);
  }
})();

// module.exports = { addToJob };
