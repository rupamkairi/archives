const { Queue, Worker } = require("bullmq");
const IORedis = require("ioredis");
const {
  // findAUMData,
  // insertManyToAUMData,
  // generateFullData,
  MongoDB,
} = require("./mongodb.utils");
const { fillMissingDataByYears } = require("./fillMissingDataByYears");
const { prettyPrintTable } = require("./prettyPrint");
const cron = require("node-cron");

const Q_NAME = "entitiesAUM";

const redis = new IORedis({
  host: "127.0.0.1",
  port: 6379,
  retryStrategy(times) {
    const delay = Math.min(times * 30, 3000);
    return delay;
  },
  reconnectOnError(err) {
    const targetError = "READONLY";
    if (err.message.includes(targetError)) {
      return true;
    }
  },
});

var fullData = [];
var pass = 0;
var step = 10;

var mongodb = new MongoDB();
mongodb.setup();

// const redis = new IORedis({
//   host: "witty-katydid-43660.upstash.io",
//   port: 43660,
//   username: "default",
//   password: "cce60b66482c4aee94ea8a5d38c4e122",
// });

// const redis = new IORedis({
//   host: "redis-14372.c57.us-east-1-4.ec2.cloud.redislabs.com",
//   port: 14372,
//   username: "default",
//   password: "L4SKEk01OFKdnvxfrIoEm27VML9UbYiY",
// });

const queue = new Queue(Q_NAME, {
  connection: redis,
});

const worker = new Worker(
  Q_NAME,
  async (job) => {
    try {
      const entityID = job.data;
      console.log("worker has", entityID);
      const data = await mongodb.findAUMData(entityID);
      const updated = fillMissingDataByYears(data);
      // prettyPrintTable(updated);
      const results = await mongodb.insertManyToAUMData(updated);
      // console.log(results);
    } catch (error) {
      console.log("Errored", error);

      const counts = await queue.getJobCounts("active", "waiting", "failed");
      console.log("Jobs failed", counts);

      console.log("closing all connections...");
      await queue.drain();
      // redis.disconnect();
      // await worker.close();
    }
  },
  {
    connection: redis,
    concurrency: 10,
  }
);

// async function addToJob(payload) {
//   try {
//     const entityID = payload;
//     console.log("worker has", entityID);
//     const data = await findAUMData(entityID);
//     const updated = fillMissingDateByYears(data);
//     // prettyPrintTable(updated);
//     const results = await insertManyToAUMData(updated);
//     // console.log(results);
//   } catch (error) {
//     console.log("Errored", error);
//     // const jobCounts = await queue.getJobCounts("active", "waiting", "failed");
//     // console.log("Jobs failed", jobCounts);
//     console.log("closing all connections...");
//     // await queue.drain();
//     // redis.disconnect();
//     // await worker.close();
//   }
// }

async function addToJob(data) {
  await queue.add(Q_NAME, data, { removeOnComplete: true, removeOnFail: true });
}

async function pushToQueue(data = []) {
  if (data.length === 0) {
    data = fullData.slice(pass * step, (pass + 1) * step);
    console.log({ data, pass, step });
  }

  for (let i = 0; i < data.length; i++) {
    await addToJob(data[i]);
  }
}

worker.on("active", (job) => {
  // console.log(job.id, "active");
});

worker.on("failed", async (job, err) => {
  console.log(job.id, "failed with error", err);
});

worker.on("completed", async (job) => {
  const { active } = await queue.getJobCounts("active", "waiting", "failed");
  console.log(job.id, "completed", { active });
  if (active == 0) {
    console.log("All jobs done successfully...");

    pass += 1;
    // const data = fullData.slice(pass * step, (pass + 1) * step);
    // console.log({ data, pass, step });

    // if (data.length === 0) return;

    // await pushToQueue(data);

    // redis.disconnect();
    // await worker.close();
  }
});

(async function main() {
  try {
    fullData = await mongodb.generateFullData();
    console.log(fullData.length, "found on pipeline");

    const data = fullData.slice(pass * step, (pass + 1) * step);
    console.log({ data, pass, step });

    //
    // for (let i = 0; i < fullData.length; i++) {
    //   // const counter = i + 1;
    const pattern = `*/10 * * * * *`;
    cron.schedule(pattern, async () => {
      console.log("\n\nRUNNING CRON");
      await pushToQueue();
      // await addToJob(fullData[i]);
    });
    // }
  } catch (error) {
    console.log("error in main", error);
  }
})();

//
//
//
// mongo connection increases too quickly within 250 entity edits it goes over 1.5k
// all task fail causes pass to not increase, but worker dont fail
// weird ordering happens - worker updates before dbops happens, but after dbops worker dont update
